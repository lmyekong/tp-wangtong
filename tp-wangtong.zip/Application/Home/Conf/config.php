<?php
return array(
	//'配置项'=>'配置值'
	'MODULE_ALLOW_LIST'=>array('Home'),
	'DEFAULT_MODULE'=>'Home',
);