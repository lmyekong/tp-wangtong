<?php
namespace Home\Controller;
use Think\Controller;
class PlugsController extends Controller {
    public function count(){

       $this->display();

    }
    public function weather(){

        $this->display();
    }
}