<?php
namespace Home\Controller;
use Think\Controller;
class NewsController extends Controller {
    public function add(){

       $this->display();

    }

    public function list(){

        $this->display();
    }
}